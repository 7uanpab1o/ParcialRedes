package ServidorStrea;

public class ImageServer {

    public static void main(String[] args) {
        ServidorStrea s = new ServidorStrea();
    }
}
