package ClienteStrea;

public class ImageClient {

    public static void main(String[] args) {
        ClienteStrea c = new ClienteStrea();
    }
}
